import { html } from "../../node_modules/lit-html/lit-html.js";
import { getAllMyItems } from "../api/data.js";
import { getUserData } from "../utility.js";

//dashboard:dash1
//replace text with variables:  ${items.name}
//replace src with image shape: src="${items.imageUrl}"
//fix href="#" :                href="/details/${x._id}"
//copy shape here:
// brand,
// model,
// description,
// year,
// imageUrl,
// price


const myDashboardTemplate = (items) => html`
<!-- My Listings Page -->
<section id="my-listings">
            <h1>My car listings</h1>
            <div class="listings">
              
           
  ${items.length == 0
    ? html` <!--Paste here: No items-->
    <p class="no-cars"> You haven't listed any cars yet.</p>
    `
    : items.map(
        (x) => html`
          <!--Paste here: the rest-->
          <!-- Display all records -->
          <div class="listing">
              <div class="preview">
                  <img src="${x.imageUrl}">
              </div>
              <h2>${x.brand} ${x.model}</h2>
              <div class="info">
                  <div class="data-info">
                      <h3>Year: ${x.year}</h3>
                      <h3>Price: ${x.price} $</h3>
                  </div>
                  <div class="data-buttons">
                      <a href="/details/${x._id}" class="button-carDetails">Details</a>
                  </div>
              </div>
          </div>
      </div>
      </section>
      `
      )}
`;


// export async function myDashboardPage(context) {
//     const userData = getUserData();
//     // if (!userData || !userData.id) {
//     //     // Handle error - redirect or show message
//     //     return;
//     // }
//     const data = await getAllMyItems(userData.id);
//     // console.log(context);
//     // console.log(data);
//     // console.log("User ID in myDashboard:", userData._id);
//     // console.log("All My Items in myDashboard:", await getAllMyItems(userData.id));
//     // console.log("Rendering data in myDashboard:", data);
//     context.render(myDashboardTemplate(data));
// }

let page = null;

export async function myDashboardPage(ctx) {
    page = ctx.page
    let user = JSON.parse(sessionStorage.getItem('user'))
    let data = await getAllMyItems();
    ctx.render(myDashboardTemplate(data, user))
}