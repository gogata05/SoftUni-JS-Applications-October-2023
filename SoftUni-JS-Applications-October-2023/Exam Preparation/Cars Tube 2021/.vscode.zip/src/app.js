//location and methods
import { render } from "../node_modules/lit-html/lit-html.js";
import page from "../node_modules/page/page.mjs";

import { logout as apiLogout } from "./api/api.js";
import { getUserData } from "./utility.js";
import { loginPage, registerPage } from "./view/auth.js";
import { homePage } from "./view/home.js";
import { dashboardPage } from "./view/dashboard.js";

import { createPage } from "./view/create.js";
import { detailsPage } from "./view/details.js";
import { editPage } from "./view/edit.js";

import { searchPage } from "./view/search.js";//remove if not bonus

import { myDashboardPage } from "./view/my-dashboard.js";//very rear when 2 collections needed///delete if not needed 2 collections

const main = document.querySelector("#site-content");//main class "content" index.html//or ".content"

setUserNav();

document.getElementById("logout-btn").addEventListener("click", onLogout);//Logout html id

// import * as api from './api/api.js';
// window.api = api;

//href and methods
page("/", decorateContext, homePage);
page("/login", decorateContext, loginPage);
page("/register", decorateContext, registerPage);
page("/dashboard", decorateContext, dashboardPage);

page("/add-item", decorateContext, createPage);//"add-item" its the url in index.html
page("/details/:id", decorateContext, detailsPage);
page("/edit/:id", decorateContext, editPage);

page("/search", decorateContext, searchPage);

page("/myDashboard", decorateContext, myDashboardPage);//very rear when 2 collections needed///delete if not needed 2 collections
page.start();

function decorateContext(ctx, next) {
  ctx.render = (content) => render(content, main);
  ctx.setUserNav = setUserNav;
  ctx.user = getUserData();
  next();
}

function setUserNav() {
  const userData = getUserData();
//or .
  if (userData) {
      document.querySelector('#profile').style.display = 'block';//!
      document.querySelector('#guest').style.display = 'none';//!
      document.querySelector('#profile a').textContent = 
      `Welcome ${userData.username}`;
  } else {
      document.querySelector('#profile').style.display = 'none';
      document.querySelector('#guest').style.display = 'block';
  }
}
//Logout button
async function onLogout() {
  await apiLogout();
  setUserNav();
  page.redirect("/");
}
